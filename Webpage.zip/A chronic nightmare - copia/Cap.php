
<?php

    $name = $_POST['name'];
    
    $email = $_POST['email'];
   
    $uname = $_POST['uname'];

    echo '<html>'

    <head>
        <title>Ayuda</title>
        <link rel="stylesheet" href="Almenosun40.css">
    </head>
    
    <body>
    
        <div id="header">
            <a href="Untitled-uwu.html">
                <div class="pixel">
                    Pixel
                </div>
            </a>
            
            <ul class="nav">
                <li><a href="Prueba.html" id="unico">Shop </a> </li>
                <li><a href="Al-Fallo.html">Community </a></li>
                <li><a href="Dios-Salvame.html">About us </a> </li>
            </ul>
    
        </div>
    
        <div    id="Lord">
            <h1>UWU</h1>
            <p class="Bak">Go back to Pixel<a href="Untitled-uwu.html">Pixel</a></p>
    
        </div>
    
    
    
        <div id="separador">
            <div id="main">
    
            </div>
    
        </div>
    
        <footer>
    
            <div id="uwu">
                <div class="D1">
                    <form action="https://twitter.com/i/flow/login">
                        <input type="image" src="social-media-g93c3e1e7b_1280.png" alt="Twitter" width="65">
                    </form>
    
                </div>
                <div class="D2">
                    <form action="https://www.instagram.com/">
                        <input type="image" src="Insta.png" alt="Insta" width=56 px>
                    </form>
    
                </div>
                <div class="D3">
    
                    <form action="https://es-la.facebook.com/">
                        <input type="image" src="Faceboock.png" alt="Face" width="56">
                    </form>
                </div>
            </div>
    
    
    
    
        </footer>
    
    
    
    
    
    
    
    
    
    
    
    
    </body>
    
    
    
    
    
    
    
    
    
    
    
    
    


?>




